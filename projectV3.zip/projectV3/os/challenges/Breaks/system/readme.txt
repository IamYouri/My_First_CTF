les dossiers path_traversal et cmd_injection doivent être dans un environnement apache afin d'être executé.
